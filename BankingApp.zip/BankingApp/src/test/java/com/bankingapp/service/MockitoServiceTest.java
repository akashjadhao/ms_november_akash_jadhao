package com.bankingapp.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

import com.bankingapp.entity.Registration;
import com.bankingapp.repository.RegistrationRepository;

@SpringBootTest(classes= {MockitoServiceTest.class})
public class MockitoServiceTest {

	@Mock
	RegistrationRepository registrationRepository;
	
	@InjectMocks
	RegistrationService registrationService;
	
	//public List<Registration> register;
	
	@Test
	@Order(1)
	public void test_getAllRegistration() {
		
		List<Registration> register = new ArrayList<>();
		
		register.add(new Registration(1001, "akash", "jadhao", 7709134, "apj@123", "apj123@gmail.com"));
		register.add(new Registration(1002, "sanket", "wankhede", 7809134, "snk@123", "snk123@gmail.com"));
		register.add(new Registration(1003, "harshada", "madghut", 8909134, "hrsd@123", "hrsh123@gmail.com"));
		register.add(new Registration(1004, "ashwini", "sharma",8809134, "ashwn@123", "ashw123@gmail.com"));
		when(registrationRepository.findAll()).thenReturn(register);
		
		//Assertions.assertEquals(1,registrationService.getAllRegistrations().size());
		Assertions.assertEquals(3,registrationService.getAllRegistrations().size());
		
	}
}
