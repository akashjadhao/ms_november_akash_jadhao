package com.bankingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bankingapp.entity.Registration;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Integer>{

	
	@Query(value= "select email_id from bank_db.registration where email_id=?1",nativeQuery = true)
	public String getEmail(String email);
	
	@Query(value= "select password from bank_db.registration where password=?1",nativeQuery = true)
	public String getPassword(String password);
}
