package com.bankingapp.entity;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "registration")
public class Registration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int user_id;
	@Column(name = "first_name", nullable = false)
	@Pattern(regexp = "^[a-zA-Z]{2,15}$")
	private String firstName;
	@Column(name = "last_name", nullable = false)
	@Pattern(regexp = "^[a-zA-Z]{2,15}$")
	private String lastName;
	@Column(nullable = false, unique = true)
	//@Pattern(regexp = "^[0-9]{10}$")
	private long mobileNo;
	@Column(nullable = false, unique = true)
	private String password;
	@Column(nullable = false, unique = true)
	@Pattern(regexp = "[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$",message = "email must be valid")
	private String emailId;

	@OneToMany
	@JoinColumn(name = "user_id")
	private List<Account> accounts;

	public Registration() {
		super();
		
	}

	public Registration(int user_id, String firstName, String lastName, long mobileNo, String password, String emailId) {
		super();
		this.user_id = user_id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.password = password;
		this.emailId = emailId;
		
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	@Override
	public String toString() {
		return "Registration [user_id=" + user_id + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", MobileNo=" + mobileNo + ", password=" + password + ", emailId=" + emailId + ", accounts="
				+ accounts + "]";
	}

}
