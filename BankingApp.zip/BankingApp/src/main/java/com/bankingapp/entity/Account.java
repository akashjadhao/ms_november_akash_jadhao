package com.bankingapp.entity;

import java.util.List;

import com.bankingapp.constants.Account_type;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	
	@Id
	@Column(name="Account_No")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long accountNo;
	@Column(nullable=false)
	private String accountType;
	@Column(nullable=false)
	private double balance;
	
	@OneToMany
	@JoinColumn(name="accountNo")
	private List<Transaction> transactions;

	public Account() {
		super();
		
	}

	public Account(long accountNo, String accountType, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.balance = balance;
	}

	public long getAccount_no() {
		return accountNo;
	}

	public void setAccount_no(long account_no) {
		this.accountNo = account_no;
	}

	public String getAccount_type() {
		return accountType;
	}

	public void setAccount_type(String account_type) {
		this.accountType = account_type;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account_Info [account_no=" + accountNo + ", account_type=" + accountType + ", balance=" + balance
				+ "]";
	}

}
