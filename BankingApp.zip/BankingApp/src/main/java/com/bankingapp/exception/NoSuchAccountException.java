package com.bankingapp.exception;

public class NoSuchAccountException extends RuntimeException {

	private String message;

	public NoSuchAccountException(String message) {

		super(message);
		this.message = message;
	}

}
