package com.bankingapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bankingapp.entity.Account;
import com.bankingapp.service.IAccountService;

@RestController
@RequestMapping("/account")
public class AccountController {
	
	private static final Logger logger = LoggerFactory.getLogger(AccountController.class);
	
	@Autowired
	private IAccountService account_InfoService;
	
	//getting all accounts
	@GetMapping(value="/getAllAccount")
	public ResponseEntity<List<Account>> getAllAccount_Infos() {
		logger.info("getting all account");
		List<Account> list = account_InfoService.getAllAccount_Infos();
		return new ResponseEntity<List<Account>>(list, HttpStatus.OK);
	}

	//getting account by ID
	@GetMapping(value="/getAccountById/{user_id}")
	public ResponseEntity<Account>  getAccount_InfoById(@PathVariable int user_id) {
		logger.info("getting account with ID : "+user_id);
		Account reg = account_InfoService.getAccount_Info(user_id);
		return new ResponseEntity<Account>(reg, HttpStatus.OK);
	}
	
	//saving account
	@PostMapping(value="/saveAccount", consumes= {MediaType.APPLICATION_JSON_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE})
	public @ResponseBody Account saveAccount_Info(@RequestBody  Account registration) {
		logger.info("saving account");
		account_InfoService.createAccount_Info(registration);
		return registration;
	}
	
	//updating account
	@PutMapping(value="/updateAccount")
	public ResponseEntity<String> updateAccount_Info(@RequestBody Account registration){
		logger.info("updating account");
		account_InfoService.updateAccount_Info(registration);
		String string = "Account Updated..";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}
	
	//delete account by ID
	@DeleteMapping(value="/deleteAccount/{user_id}")
	public ResponseEntity<String> deleteAccount_Info(@PathVariable int user_id){
		
		logger.info("deleting account with ID : "+user_id);
		account_InfoService.deleteAccount_Info(user_id);
		String string = "Account Deleted..";
		return new ResponseEntity<String>(string, HttpStatus.OK);
		
	}
	

}
