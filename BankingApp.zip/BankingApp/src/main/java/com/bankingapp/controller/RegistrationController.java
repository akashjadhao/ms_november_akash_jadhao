package com.bankingapp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bankingapp.entity.Registration;
import com.bankingapp.service.IRegistrationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/registration")
public class RegistrationController {
	
	private static final Logger logger = LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	private IRegistrationService registrationService;

	//login method
	@GetMapping("/login")
	public String login(@RequestParam("email") String email, @RequestParam("password") String password) {
		logger.info("logging with email : "+email);
		return registrationService.login(email, password);
	}
	
	@PostMapping(value = "/saveRegistration", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })
	public @ResponseBody Registration saveRegistration(@Valid @RequestBody Registration registration) {

		registrationService.saveRegistration(registration);
		return registration;
	}

	//getting all register customer
	@GetMapping(value = "/getAllRegistrations")
	public ResponseEntity<List<Registration>> getAllRegistrations() {
		logger.info("getting all register custmer");
		List<Registration> list = registrationService.getAllRegistrations();
		return new ResponseEntity<List<Registration>>(list, HttpStatus.OK);
	}

	//getting register customer by ID
	@GetMapping(value = "/getRegistrationById/{user_id}")
	public ResponseEntity<Registration> getRegistrationById(@PathVariable int user_id) {
		logger.info("getting register customer by ID : "+user_id);
		Registration reg = registrationService.getRegistrationById(user_id);
		return new ResponseEntity<Registration>(reg, HttpStatus.OK);
	}

	//updating customer information
	@PutMapping(value = "/updateRegistration")
	public ResponseEntity<String> updateRegistration(@RequestBody Registration registration) {

		registrationService.updateRegistration(registration);
		String string = "Updated Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);
	}

	//delete customer
	@DeleteMapping(value = "/deleteRegistration/{user_id}")
	public ResponseEntity<String> deleteRegistration(@PathVariable int user_id) {
		logger.info("deleting customer of ID : "+user_id);
		registrationService.deleteRegistration(user_id);
		String string = "Deleted Successfully";
		return new ResponseEntity<String>(string, HttpStatus.OK);

	}
	
	 @ResponseStatus(HttpStatus.BAD_REQUEST)
	    @ExceptionHandler(MethodArgumentNotValidException.class)
	    public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) 
	    {
	        Map<String, String> errors = new HashMap<>();

	        ex.getBindingResult().getFieldErrors().forEach(error ->
	                errors.put(error.getField(), error.getDefaultMessage()));

	        return errors;
	    }
	


}
