package com.bankingapp.constants;

public enum Account_type {
	
	Savings_Account, Current_Account;
}
