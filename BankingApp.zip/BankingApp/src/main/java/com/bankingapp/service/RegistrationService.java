package com.bankingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingapp.entity.Registration;
import com.bankingapp.exception.NoSuchAccountException;
import com.bankingapp.repository.RegistrationRepository;

import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class RegistrationService implements IRegistrationService{
	
	@Autowired
	private RegistrationRepository registrationRepo;

	@Override
	public List<Registration> getAllRegistrations() {
		
		return registrationRepo.findAll();
	}

	@Override
	public Registration getRegistrationById(int id) {
		
		return  registrationRepo.findById(id).orElseThrow(
				()-> new NoSuchAccountException("NO Registration PRESENT WITH ID = " + id));
	}

	@Override
	public void saveRegistration(Registration registrion) {
		
		registrationRepo.save(registrion);
	}
	

	@Override
	public void updateRegistration(Registration registrion) {
		
		int id = registrion.getUser_id();
		Registration reg = registrationRepo.findById(id).get();
		reg.setMobileNo(registrion.getMobileNo());
		reg.setFirstName(registrion.getFirstName());
		reg.setLastName(registrion.getLastName());
		reg.setPassword(registrion.getPassword());
		reg.setEmailId(registrion.getEmailId());
		registrationRepo.save(reg);
	}

	@Override
	public void deleteRegistration(int id) {

		registrationRepo.deleteById(id);
	}
	
	@Override
	public String login(String email, String password) {
		if (email.equals(registrationRepo.getEmail(email)) && password.equals(registrationRepo.getPassword(password)))
				return "Login Succesfull";
		return "Login failed";
		
		
	}

}
