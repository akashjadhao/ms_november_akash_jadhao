package com.bankingapp.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingapp.entity.Account;
import com.bankingapp.entity.Transaction;
import com.bankingapp.exception.InsufficientFundsException;
import com.bankingapp.repository.AccountRepository;
import com.bankingapp.repository.TransactionRepository;

@Service
public class TransactionService  implements ITransactionService{
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private AccountRepository account_InfoRepo;

	@Override
	public Transaction createTransaction(Transaction transaction) {

		return transactionRepository.save(transaction);
	}

	@Override
	public void deleteTransaction(long id) {

		transactionRepository.findById(id)
				.orElseThrow(() -> new NoSuchElementException("No such transaction exists " +id));

		transactionRepository.deleteById(id);
	}

	@Override
	public Transaction getTransactionsForAccount(long accountId) {

	
		return null;
	}

	@Override
	public Transaction getTransaction(long transactionId) {

		return transactionRepository.findById(transactionId)
				.orElseThrow(() -> new NoSuchElementException("No such transaction exists " + transactionId));
	}

	@Override
	public Transaction updateTransaction(Transaction transaction) {

		transactionRepository.findById(transaction.getTx_id())
				.orElseThrow(() -> new NoSuchElementException("No such transaction exists " + transaction.getTx_amount()));

		return transactionRepository.save(transaction);
	}

	@Override
	public List<Transaction> getAllTransactions() {
	
		return transactionRepository.findAll();	
	}

	@Override
	public void debit(long account_number, double amount) throws InsufficientFundsException {
	
		Account info = account_InfoRepo.findById(account_number).orElseThrow(
				()->new NoSuchElementException("No Such Account Exists" +account_number));
		if(info.getBalance()-amount<1500)
			throw new InsufficientFundsException("Insufficient Funds !!"+info.getBalance());
		
		info.setBalance(info.getBalance()-amount);
		
	}

	@Override
	public void credit(long account_number, double amount) {
	
		Account info = account_InfoRepo.findById(account_number).orElseThrow(
				()->new NoSuchElementException("No Such Account Exists" +account_number));
		
		info.setBalance(info.getBalance()+amount);
		
	}



}
