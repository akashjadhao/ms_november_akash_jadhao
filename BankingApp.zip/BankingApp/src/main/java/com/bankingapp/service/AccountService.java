package com.bankingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankingapp.entity.Account;
import com.bankingapp.exception.NoSuchAccountException;
import com.bankingapp.repository.AccountRepository;

@Service
public class AccountService implements IAccountService{
	
	@Autowired
	private AccountRepository account_InfoRepo;

	@Override
	public Account createAccount_Info(Account account_info) {
	
		return account_InfoRepo.save(account_info);
	}

	@Override
	public void deleteAccount_Info(long id) {

		account_InfoRepo.findById(id).orElseThrow(
				() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + id));
		account_InfoRepo.deleteById(id);
	}


	@Override
	public Account getAccount_Info(long id) {

		return account_InfoRepo.findById(id)
				.orElseThrow(() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + id));
	}

	@Override
	public Account updateAccount_Info(Account account_info) {

		Account account = account_InfoRepo.findById(account_info.getAccount_no()).orElseThrow(
				() -> new NoSuchAccountException("NO account PRESENT WITH ID = " + account_info.getAccount_no()));
		
		account.setAccount_type(account_info.getAccount_type());
		account.setBalance(account_info.getBalance());
		return account_InfoRepo.save(account);
		
	}

	@Override
	public List<Account> getAllAccount_Infos() {
		
		return account_InfoRepo.findAll();
	}

}
