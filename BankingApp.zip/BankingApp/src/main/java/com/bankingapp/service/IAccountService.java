package com.bankingapp.service;

import java.util.List;

import com.bankingapp.entity.Account;

public interface IAccountService {
	
	Account createAccount_Info(Account Account_Info);

	void deleteAccount_Info(long id);

	Account getAccount_Info(long id);

	Account updateAccount_Info(Account Account_Info);

	List<Account> getAllAccount_Infos();

}
